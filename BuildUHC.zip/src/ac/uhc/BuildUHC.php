<?php

namespace ac\uhc;

use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\Task as PluginTask;
use pocketmine\event\Listener;
use pocketmine\level\sound\PopSound;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\TextFormat as TE;
use pocketmine\utils\Config;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\tile\Sign;
use pocketmine\level\Level;
use pocketmine\item\Item;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\tile\Chest;
use pocketmine\inventory\ChestInventory;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\entity\Effect;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\block\Air;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;

use ac\uhc\ResetMap;

class BuildUHC extends PluginBase implements Listener {

	public static $plugin;

     public $prefix = TE::GRAY . "»" . TE::WHITE . TE::RED . "§cBuild" . TE::WHITE . "§fUHC" . TE::RESET . TE::GRAY . "«";
	public $mode = 0;
	public $arenas = array();
	public $currentLevel = "";
	
	public function onEnable()
	{
		$this->getServer()->getLogger()->info("§b§lBuildUHC Ligado!");
                $this->getServer()->getPluginManager()->registerEvents($this ,$this);
		@mkdir($this->getDataFolder());
        
		$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
          
		if($config->get("arenas")!=null)
		{
			$this->arenas = $config->get("arenas");
		}
		foreach($this->arenas as $lev)
		{
			$this->getServer()->loadLevel($lev);
		}
		$itemsFall = array(array(1,0,30),array(1,0,20),array(3,0,15),array(3,0,25),array(4,0,35),array(4,0,15),array(260,0,5),array(261,0,1),array(262,0,6),array(267,0,1),array(268,0,1),array(272,0,1),array(276,0,1),array(283,0,1),array(297,0,3),array(298,0,1),array(299,0,1),array(300,0,1),array(301,0,1),array(303,0,1),array(304,0,1),array(310,0,1),array(313,0,1),array(314,0,1),array(315,0,1),array(316,0,1),array(317,0,1),array(320,0,4),array(354,0,1),array(364,0,4),array(366,0,5),array(391,0,5));
		if($config->get("chestitems")==null)
		{
			$config->set("chestitems",$itemsFall);
		}
		
		$config->save();
		
		
                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                $slots->save();
		$this->getScheduler()->scheduleRepeatingTask(new GameSender($this), 20);
		$this->getScheduler()->scheduleRepeatingTask(new RefreshSigns($this), 10);
	}

	public static function getMain() {
		return self::$plugin;
	}

        public function enCambioMundo(EntityLevelChangeEvent $event)
        {
            $pl = $event->getEntity();
            if($pl instanceof Player)
            {
                $lev = $event->getOrigin();
                $level = $lev->getFolderName();
                if($lev instanceof Level && in_array($level,$this->arenas))
		{
                $pl->removeAllEffects();
                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                for ($i = 1; $i <= 12; $i++) {
                    if($slots->get("slot".$i.$level)==$pl->getName())
                    {
                        $slots->set("slot".$i.$level, 0);
                    }
                }
                $slots->save();
                }
            }
        }

	public function onDeath(PlayerDeathEvent $event){
        $jugador = $event->getEntity();
        $mapa = $jugador->getLevel()->getFolderName();
$player = $jugador->getPlayer();
        if(in_array($mapa,$this->arenas))
		{
                if($event->getEntity()->getLastDamageCause() instanceof EntityDamageByEntityEvent)
                {
                $asassin = $event->getEntity()->getLastDamageCause()->getDamager();
                if($asassin instanceof Player){
                $event->setDeathMessage("");
                foreach($jugador->getLevel()->getPlayers() as $pl){
				
                                $muerto = $jugador->getName();
                                $asesino = $asassin->getName();
				$pl->sendMessage("$muerto §7assassinado por§f $asesino");
			}
                }
                }
                $jugador->setNameTag($jugador->getName());
                }
        }
	
	
	public function onLog(PlayerLoginEvent $event)
	{
		$player = $event->getPlayer();
                if(in_array($player->getLevel()->getFolderName(),$this->arenas))
		{
		$player->getInventory()->clearAll();
		$spawn = $this->getServer()->getDefaultLevel()->getSafeSpawn();
		$this->getServer()->getDefaultLevel()->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
		$player->teleport($spawn,0,0);
                }
	}
        
        public function onQuit(PlayerQuitEvent $event)
        {
            $pl = $event->getPlayer();
            $level = $pl->getLevel()->getFolderName();
            if(in_array($level,$this->arenas))
            {
                $pl->removeAllEffects();
                $pl->getArmorInventory()->clearAll();
                $pl->getInventory()->clearAll();
                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                $pl->setNameTag($pl->getName());
                if($slots->get("slot1".$level)==$pl->getName())
                {
                    $slots->set("slot1".$level, 0);
                }
                if($slots->get("slot2".$level)==$pl->getName())
                {
                    $slots->set("slot2".$level, 0);
                }
                $slots->save();
            }
        }

	public function onBlockBreak(BlockBreakEvent $event)
	{
		$player = $event->getPlayer();
		$level = $player->getLevel()->getFolderName();
		if(in_array($level,$this->arenas))
		{
                        $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                        if($config->get($level . "PlayTime") != null)
                        {
          $event->setCancelled(false);
                            {
                                if($config->get($level . "PlayTime") > 479)
                                {
                                        $event->setCancelled(true);
                                }
                        }
            }
		}
	}
	
	public function onBlockPlace(BlockPlaceEvent $event)
	{
		$player = $event->getPlayer();
		$level = $player->getLevel()->getFolderName();
		if(in_array($level,$this->arenas))
		{
                        $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                        if($config->get($level . "PlayTime") != null)
                        {
          $event->setCancelled(false);
                            {
                                if($config->get($level . "PlayTime") > 479)
                                {
                                        $event->setCancelled(true);
                                }
                        }
            }
		}
	}
	
	public function onDamage(EntityDamageEvent $event)
	{
		if($event instanceof EntityDamageByEntityEvent)
		{
			$player = $event->getEntity();
			$damager = $event->getDamager();
 		$level = $player->getLevel()->getFolderName();
			if($player instanceof Player)
		if(in_array($level,$this->arenas))
			{
				if($damager instanceof Player)
				{
					$level = $player->getLevel()->getFolderName();
					$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
					if($config->get($level . "PlayTime") != null)
					{
     $event->setCancelled(false);
}
						if($config->get($level . "PlayTime") > 479)
						{
							$event->setCancelled(true);
						}
					}
				}
			}
		}
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args):bool {
        switch($cmd->getName()){
			case "uhc":
				if($player->isOp())
				{
					if(!empty($args[0]))
					{
						if($args[0]=="criar")
						{
							if(!empty($args[1]))
							{
								if(file_exists($this->getServer()->getDataPath() . "/worlds/" . $args[1]))
								{
									$this->getServer()->loadLevel($args[1]);
									$this->getServer()->getLevelByName($args[1])->loadChunk($this->getServer()->getLevelByName($args[1])->getSafeSpawn()->getFloorX(), $this->getServer()->getLevelByName($args[1])->getSafeSpawn()->getFloorZ());
									array_push($this->arenas,$args[1]);
									$this->currentLevel = $args[1];
									$this->mode = 1;
									$player->sendMessage($this->prefix . "§a»Marque as posições dos 2 jogadores");
									$player->sendMessage($this->prefix . "§a»e a terceira posição será o lobby");
									$player->setGamemode(1);
									$player->teleport($this->getServer()->getLevelByName($args[1])->getSafeSpawn(),0,0);
                                                                        $name = $args[1];
                                                                        $this->zipper($player, $name);
								}
								else
								{
									$player->sendMessage($this->prefix . "Mundo invalido.");
								}
							}
							else
							{
								$player->sendMessage($this->prefix . "parâmetros ausentes");
							}
						}
						else
						{
							$player->sendMessage($this->prefix . "Comando invalido");
						}
					}
					else
					{
					 $player->sendMessage($this->prefix . "§7 Comandos§7«");
                                         $player->sendMessage($this->prefix . "§a» /uhc criar [mundo]: Criar jogo buhc!");
                                         $player->sendMessage($this->prefix . "§a» /uhciniciar: iniciar partida uhc");
					}
				}
				else
				{
				}
			
			return true;
                        
                        case "uhciniciar":
                            if($player->isOp())
				{
                                $player->sendMessage("§7Em 5 segundos começa!");
                                $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                                $config->set("arenas",$this->arenas);
                                foreach($this->arenas as $arena)
                                {
                                        $config->set($arena . "PlayTime", 480);
                                        $config->set($arena . "StartTime", 5);
                                }
                                $config->save();
                                }
                                return true;
                                
              
                                
                 
	}
        }
        
        
	public function onInteract(PlayerInteractEvent $event)
	{
  $item = $event->getItem();
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$tile = $player->getLevel()->getTile($block);
 	$itemname = $item->getCustomName();
    if ($itemname === "§aVoltar ao lobby"){
						$default = Server::getInstance()->getDefaultLevel()->getSafeSpawn();
						$player->teleport($default);
     $player->getInventory()->clearAll();
}
		if($tile instanceof Sign) 
		{
			if($this->mode==26)
			{
				$tile->setText(TE::AQUA . "§7[§fEntrada§7]",TE::GREEN  . "0 - 2","§f" . $this->currentLevel,$this->prefix);
				$this->refreshArenas();
				$this->currentLevel = "";
				$this->mode = 0;
				$player->sendMessage($this->prefix . "Arena registrada");
			}
			else
			{
				$text = $tile->getText();
				if($text[3] == $this->prefix)
				{
					if($text[0]==TE::AQUA . "§7[§fEntrada§7]")
					{
						$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
                                                $slots = new Config($this->getDataFolder() . "/slots.yml", Config::YAML);
                                                $namemap = str_replace("§f", "", $text[2]);
						$level = $this->getServer()->getLevelByName($namemap);
                                                if($slots->get("slot1".$namemap)==null)
                                                {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot1".$namemap, $player->getName());
                                                        $slots->save();
                                                }
                                                else if($slots->get("slot2".$namemap)==null)
                                                {
                                                        $thespawn = $config->get($namemap . "Spawn3");
                                                        $slots->set("slot2".$namemap, $player->getName());
                                                        $slots->save();
                                                }
                                                                       foreach($level->getPlayers() as $playersinarena)
                                                        {
                                                                                                                $playersinarena->sendMessage($player->getName() . " §a» Junte-se ao jogo ");
                                                }
                                                $player->sendMessage("§a» Junte-se ao jogo §cBuild§fUHC§7!");
												$player->addTitle(("§cBuild§fUHC"), ("§7Mapa: §f$namemap"));
						$spawn = new Position($thespawn[0]+0.5,$thespawn[1],$thespawn[2]+0.5,$level);
						$level->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
						$player->teleport($spawn,0,0);
						$player->getInventory()->clearAll();
						$player->getArmorInventory()->clearAll();
$hub = Item::get(0,0,0);
		$hub->setCustomName("§aDe volta ao lobby");
		$player->getInventory()->setItem(0,
$hub);
                                                $player->removeAllEffects();
                                                $player->setMaxHealth(20);
$player->setGamemode(2);
                                                $player->setHealth(20);
                                                $player->setFood(20);
                                             	      if(strpos($player->getNameTag(), "Player") !== false)
                                                {
                                            
                                                    $player->sendMessage("§b Você não é permitido neste jogo!");
                                                }
                                                
                                                
                                                
                                                
                                                

				  
 
				
     
					}
					
				}
			}
		}
		else if($this->mode>=1&&$this->mode<=2)
		{
			$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
			$config->set($this->currentLevel . "Spawn" . $this->mode, array($block->getX(),$block->getY()+1,$block->getZ()));
			$player->sendMessage($this->prefix . "Spawn " . $this->mode . " Registrado§b!");
			$this->mode++;
			$config->save();
		}
		else if($this->mode==3)
		{
			$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
			$config->set($this->currentLevel . "Spawn" . $this->mode, array($block->getX(),$block->getY()+1,$block->getZ()));
			$player->sendMessage($this->prefix . "Spawn " . $this->mode . " §7lobby foi registrado");
			$config->set("arenas",$this->arenas);
			$player->sendMessage($this->prefix . "Toque em um sinal para procurar na arena!");
			$spawn = $this->getServer()->getDefaultLevel()->getSafeSpawn();
			$this->getServer()->getDefaultLevel()->loadChunk($spawn->getFloorX(), $spawn->getFloorZ());
			$player->teleport($spawn,0,0);
			$config->save();
			$this->mode=26;
		}
	}
	
	public function refreshArenas()
	{
		$config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
		$config->set("arenas",$this->arenas);
		foreach($this->arenas as $arena)
		{
			$config->set($arena . "PlayTime", 480);
			$config->set($arena . "StartTime", 30);
		}
		$config->save();
	}
        
        public function zipper($player, $name)
        {
        $path = realpath($player->getServer()->getDataPath() . 'worlds/' . $name);
				$zip = new \ZipArchive;
				@mkdir($this->getDataFolder() . 'arenas/', 0755);
				$zip->open($this->getDataFolder() . 'arenas/' . $name . '.zip', $zip::CREATE | $zip::OVERWRITE);
				$files = new \RecursiveIteratorIterator(
					new \RecursiveDirectoryIterator($path),
					\RecursiveIteratorIterator::LEAVES_ONLY
				);
                                foreach ($files as $datos) {
					if (!$datos->isDir()) {
						$relativePath = $name . '/' . substr($datos, strlen($path) + 1);
						$zip->addFile($datos, $relativePath);
					}
				}
				$zip->close();
				$player->getServer()->loadLevel($name);
				unset($zip, $path, $files);
        }
}

class RefreshSigns extends PluginTask {
     public $prefix = TE::GRAY  . "»" . TE::WHITE . TE::RED . "§cBuild" . TE::WHITE . "§fUHC" . TE::RESET . TE::GRAY . "«";
	public function __construct($plugin)
	{
		$this->plugin = $plugin;
	}
  
	public function onRun($tick)
	{
		$allplayers = $this->plugin->getServer()->getOnlinePlayers();
		$level = $this->plugin->getServer()->getDefaultLevel();
		$tiles = $level->getTiles();
		foreach($tiles as $t) {
			if($t instanceof Sign) {	
				$text = $t->getText();
				if($text[3]==$this->prefix)
				{
					$aop = 0;
                                        $namemap = str_replace("§f", "", $text[2]);
					foreach($allplayers as $player){if($player->getLevel()->getFolderName()==$namemap){$aop=$aop+1;}}
					$ingame = TE::AQUA . "§7[§fEntrada§7]";
					$config = new Config($this->plugin->getDataFolder() . "/config.yml", Config::YAML);
					if($config->get($namemap . "PlayTime")!=480)
					{
						$ingame = TE::DARK_PURPLE . "§7[§4Corrida§7]";
					}
					else if($aop>=2)
					{
						$ingame = TE::GOLD . "§4[§7Cheio§4]";
					}
					$t->setText($ingame,TE::GREEN  . $aop . " - 2",$text[2],$this->prefix);
				}
			}
		}
	}
}

class GameSender extends PluginTask {
     public $prefix = TE::GRAY . "»" . TE::WHITE . TE::RED . "§cBuild" . TE::WHITE . "§fUHC" . TE::RESET . TE::GRAY . "«";
	public function __construct($plugin)
	{
		$this->plugin = $plugin;
	}
        
        public function getResetmap() {
        Return new ResetMap($this);
        }
  
	public function onRun($tick)
	{
		$slots = new Config($this->plugin->getDataFolder() . "/slots.yml", Config::YAML);
		$config = new Config($this->plugin->getDataFolder() . "/config.yml", Config::YAML);
		$arenas = $config->get("arenas");
            
		if(!empty($arenas))
		{
			foreach($arenas as $arena)
			{
				$time = $config->get($arena . "PlayTime");
				$timeToStart = $config->get($arena . "StartTime");
				$levelArena = $this->plugin->getServer()->getLevelByName($arena);
				if($levelArena instanceof Level)
				{
					$playersArena = $levelArena->getPlayers();
					if(count($playersArena)==0)
					{
						$config->set($arena . "PlayTime", 480);
						$config->set($arena . "StartTime", 30);
					}
					else
					{
						if(count($playersArena)>=2)
						{
							if($timeToStart>0)
							{
								$timeToStart--;
								foreach($playersArena as $pl)
								{
         $pl->sendTip("§7»§cBuild§fUHC§7«\n§a»§fInicia em $timeToStart");
								}
								
								
								
                                                                if($timeToStart==29)
                                                                {
                                                                    $levelArena->setTime(7000);
                                                                    $levelArena->stopTime();
                                                                }
								if($timeToStart<=0)
								{
									$this->refillChests($levelArena);
                                                                  
								}
								       if($timeToStart<=5)
                                                                        {
                                                                        $levelArena->addSound(new PopSound($pl));
                                                                        }
                                                                        if($timeToStart<=0)
                                                                        {
                                                                        $levelArena->addSound(new AnvilUseSound($pl));
                                                                        }
								
								    if($timeToStart ==10 || $timeToStart ==9 || $timeToStart ==8 || $timeToStart ==7)
									{
										foreach($playersArena as $pl)
										{
											
											$pl->sendMessage("§a» jogo começa em§f $timeToStart ");
									
										}
									}
									 if($timeToStart ==6 || $timeToStart ==5 || $timeToStart ==4 || $timeToStart ==3)
									{
										foreach($playersArena as $pl)
										{
											
											$pl->sendMessage("§a» jogo começa em§f $timeToStart ");
									
										}
									}
									 if($timeToStart == 2 || $timeToStart ==1 || $timeToStart ==0)
									{
										foreach($playersArena as $pl)
										{
											
											$pl->sendMessage("§a» jogo começa em§f $timeToStart ");
									
										}
									}
									
								    if($timeToStart<=0)
								{
                                                                    foreach($playersArena as $pla)
                                                                    {
                                                                        if($slots->get("slot1".$arena)==$pla->getName())
                                                                        {
                                                                                $thespawn = $config->get($arena . "Spawn1");
                                                                        }
                                                                        elseif($slots->get("slot2".$arena)==$pla->getName())
                                                                        {
                                                                                $thespawn = $config->get($arena . "Spawn2");
                                                                        }
                                                                        $spawn = new Position($thespawn[0]+0.5,$thespawn[1],$thespawn[2]+0.5,$levelArena);
                                                                        $pla->teleport($spawn,0,0);

$pla->getArmorInventory()->setHelmet(Item::get(Item::DIAMOND_HELMET));
							                                                $pla->getArmorInventory()->setChestplate(Item::get(Item::DIAMOND_CHESTPLATE));
							                                                $pla->getArmorInventory()->setLeggings(Item::get(Item::DIAMOND_LEGGINGS));
							                                                $pla->getArmorInventory()->setBoots(Item::get(Item::DIAMOND_BOOTS));
							                                                $pla->getInventory()->setItem(0, Item::get(Item::DIAMOND_SWORD, 0, 1));
							                                                $pla->getInventory()->addItem(Item::get(ITEM::COBBLESTONE, 0, 64));
		                                                                    $pla->getInventory()->addItem(Item::get(ITEM::GOLDEN_APPLE, 0, 6));
							                                                $pla->getInventory()->addItem(Item::get(ITEM::BOW, 0, 1));
							                                                $pla->getInventory()->addItem(Item::get(ITEM::ARROW, 0, 64));

			$hub = Item::get(0,0,0);
			$hub->setCustomName("§avoltar ao lobby");
			$pla->getInventory()->removeItem($hub);
                                                                    }
                                                                    }
     
								$config->set($arena . "StartTime", $timeToStart);
							}
							else
							{
								$aop = count($levelArena->getPlayers());
								if($aop==1)
								{
									foreach($playersArena as $pl)
									{
									$this->plugin->getServer()->broadcastMessage("§a«=======================»
          §a" . $pl->getName() . "
    §eVencedor do §cBuild§fUHC!

§a«=======================»");

     $pl->getInventory()->clearAll();
										$pl->removeAllEffects();
										$pl->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn(),0,0);
                                                                                $pl->setHealth(20);
                                                                                $pl->setFood(20);
                                                                                $pl->setNameTag($pl->getName());
                                                                                
                                                                                $this->getResetmap()->reload($levelArena);
                                                                                }
                                                                                $config->set($arena . "PlayTime", 480);
                                                                                $config->set($arena . "StartTime", 30);
								}
                                                                if(($aop>=2))
                                                                    {
                                                                    foreach($playersArena as $pl)
                                                                        {
                                               	  $player = $pl->getPlayer()->getName();
                                           $date = date("d/m/y");
                                                                        }
                                                                          
                                                                }
                                                            
								$time--;
								if($time == 479)
								{
                                                                        $slots = new Config($this->plugin->getDataFolder() . "/slots.yml", Config::YAML);
                                                                        $slots->set("slot1".$arena, 0);
                                                                        $slots->set("slot2".$arena, 0);
                                                                        $slots->save();
									foreach($playersArena as $pl)
									{
$pl->setGamemode(0);
										$pl->addTitle("§cBuild§fUHC");
$pl->sendMessage(TE::AQUA."§a»-------------------");
                                                                            $pl->sendMessage("§a»Início da partida, Mapa: §f $arena ");
                                                                            $pl->sendMessage("§cLUTEM!");                                                                         $pl->sendMessage(TE::AQUA."§a»-------------------");
									}
								}
                                                       
                                                                if($time == 400)
								{
									foreach($playersArena as $pl)
									{
										$pl->sendMessage("§a»Quem serar o vencedor??");
									}
								}
                                                        
								if($time == 300)
								{
										foreach($playersArena as $pl)
										{
										$pl->sendMessage("§a»-------------------");
                                                                                $pl->sendMessage("§cLUTEM");
                                                                                $pl->sendMessage("§a»-------------------");
										}
									}

									else if($time == 30 || $time == 15 || $time == 10 || $time ==5 || $time ==4 || $time ==3 || $time ==2 || $time ==1)
									{
										foreach($playersArena as $pl)
										{
											
											$pl->sendMessage("§f»§f Hora do jogo terminar§f $time ");
										}
									}
									if($time <= 0)
									{
										foreach($playersArena as $pl)
										{
											$pl->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn(),0,0);
											
											
											$pl->sendMessage("§a=========================

         §aNão o vencedor!
         §cBuild§fUHC

§a=========================");
                                                                                        $pl->removeAllEffects();
     $pl->getInventory()->clearAll();
                                                                                        $pl->setFood(20);
                                                                                        $pl->setHealth(20);
                                                                                        $pl->setNameTag($pl->getName());
                                                                                        $this->getResetmap()->reload($levelArena);
										}
										$time = 480;
									}
								}
								$config->set($arena . "PlayTime", $time);
							}
						else
						{
							if($timeToStart<=0)
							{
								foreach($playersArena as $pl)
								{
									$this->plugin->getServer()->broadcastMessage("§a=========================

          §a" . $pl->getName() . "
    §eVencedor do §cBuild§fUHC

§a=========================");
     $pl->getInventory()->clearAll();
									$pl->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn(),0,0);
                                                                        $pl->removeAllEffects();
                                                                        $pl->setHealth(20);
                                                                        $pl->setFood(20);
                                                                        $pl->setNameTag($pl->getName());
                                                                    
                                                                        $this->getResetmap()->reload($levelArena);
								}
								$config->set($arena . "PlayTime", 480);
								$config->set($arena . "StartTime", 30);
							}
							else
							{
								         foreach($playersArena as $pl)
                                                    {
                                                    
                                                    	  $player = $pl->getPlayer()->getName();
         $pl->sendTip("§a»§cBuild§fUHC§a«\n§a»§f Tempo de espera§f $timeToStart second");
           }
								$config->set($arena . "PlayTime", 480);
								$config->set($arena . "StartTime", 30);
							}
						}
					}
				}
			}
  }
		$config->save();
	}
	
	public function refillChests(Level $level)
	{
		$config = new Config($this->plugin->getDataFolder() . "/config.yml", Config::YAML);
		$tiles = $level->getTiles();
		foreach($tiles as $t) {
			if($t instanceof Chest) 
			{
				$chest = $t;
				$chest->getInventory()->clearAll();
				if($chest->getInventory() instanceof ChestInventory)
				{
					for($i=0;$i<=26;$i++)
					{
						$rand = rand(1,3);
						if($rand==1)
						{
							$k = array_rand($config->get("chestitems"));
							$v = $config->get("chestitems")[$k];
							$chest->getInventory()->setItem($i, Item::get($v[0],$v[1],$v[2]));
						}
					}									
				}
			}
		}
	}
}